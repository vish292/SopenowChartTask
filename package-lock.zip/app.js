// document.addEventListener("DOMContentLoaded", function() {
//     // Sample data for the chart
//     const chartData = {
//       categories: ['Category 1', 'Category 2', 'Category 3', 'Category 4', 'Category 5'],
//       series: [44, 55, 41, 17, 15],
//     };
  
//     // Options for the chart
//     const chartOptions = {
//       chart: {
//         type: 'bar',
//       },
//       plotOptions: {
//         bar: {
//           horizontal: false,
//         }
//       },
//       xaxis: {
//         categories: chartData.categories,
//       },
//     };
  
//     // Create the chart
//     const chart = new ApexCharts(document.querySelector("#chart"), chartOptions);
  
//     // Render the chart
//     chart.render();
//   });